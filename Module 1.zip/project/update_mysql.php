<?php
include("database.php");

extract($_POST);
$UserID = $_GET['id'];

$type = implode(",", $_POST['UserType']);
	
	$sql = "UPDATE user SET UserPhoneNum='$phoneNum', UserType='$type', UserAddress='$address' WHERE id='$UserID'";

	$result = mysqli_query($link,$sql) or die(mysqli_error());
	
	if($result)
	{
		echo "<script> window.location='displayGender.php' </script>";
	}

//Connect to the database server.
$link = mysqli_connect("localhost", "root", "", "group2") or die(mysqli_connect_error());

//Select the database.
mysqli_select_db($link, "group2") or die(mysqli_error($link));
$UserData = mysqli_fetch_assoc($result);
$UserID = $UserData['UserID'];
$phoneNum = $UserData['UserPhoneNum'];
$type = $UserData['UserType'];
$address = $UserData['UserAddress'];
//SQL query
$query = "UPDATE User SET UserID='$UserID', UserPhoneNum='$phoneNum' , UserType='$type' , UserAddress='$address'";

//Execute the query (the recordset $rs contains the result)
$result = mysqli_query($link, $query);

if ($result) {
    echo "<script> window.location='updateUser.php' </script>";
}
?>
<!--Loop the recordset $rs 
while ($UserData=mysqli_fetch_array($result)){

//Write the value of the column FirstName and Address
echo $UserData['FirstName']. "  ". $UserData['Address']. "<br/>";
}

//Close the database connection
mysqli_close($link);-->