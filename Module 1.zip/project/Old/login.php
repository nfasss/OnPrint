
<!DOCTYPE html>

<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Inter&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <div class="top_nav">
            <ul>
                <img src="ONPRINT LOGO.png" style="float:left;" alt="ONPRINT" width="40" height="40">
                <li style="float:left;"><a href="#explore">EXPLORE</a></li>
                <li style="float:right;"><a href="#home">Home</a></li>
                <li style="float:right;"><a href="#order">Order</a></li>
                <li style="float:right;"><a href="#profile">Our Profile</a></li>
                <li style="float:right;"><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </header>
    <div class="picture">
        <img src="umplawo.jpg">
    </div>

    <div class="title">
        <h2>LOGIN</h2>
    </div>

    <div id="login">
        <form class="container_L" action="" method="post">
            <label>User ID:</label><input type="text" name="UserID" placeholder="Enter User ID"><br>
            <label>Password:</label><input type="password" name="UserPassword" placeholder="Enter password"><br>
            <label>User Type:</label>
            <select id="userType" name="userType">
                <option value="staff">Staff</option>
                <option value="student">Student</option>
                <option value="administrator">Administrator</option>
            </select>
            <br>

            <input type="button" class="btn1" value="Login" style="padding: 10px 50px;" onclick=" location.href='homepage.php'">
            <input type="button" class="btn2" value="Register" style="padding: 10px 50px;" onclick=" location.href='register1.php'">
        </form>
    </div>

    <footer>
        <h4>Unless explicitly stated otherwise, all material is copyright &copy; OnPrint 2022.</h4>
    </footer>
</body>

</html>

<style>
    * {
        box-sizing: border-box;
    }

    .img {
        margin-top: 0px;
    }

    body {
        font-size: 14px;
        width: 100%;
        height: 827px;
        background: rgba(2, 53, 121, 1);
        opacity: 1;
        position: absolute;
        top: 0px;
        left: 0px;

    }

    /* Setting top_nav */
    header {
        background-color: #FFDE59;
        margin: 0;
        height: 50px;

    }

    .top_nav {
        left: 0px;
        top: 0px;
        margin: 0px;
        border: 0;
        padding-top: 10px;
        width: 100%;
        font-size: 20px;

    }

    .top_nav ul {
        /*    width: 100%; */
        display: inline;
        padding: 0 50px;
        color: black;
        text-align: center;
        /*    overflow: hidden; */
        Left: 0px;
        margin: 0px;

    }

    .top_nav li {
        margin-right: 0;
        text-transform: uppercase;
        letter-spacing: 0px;
        list-style-type: none;
    }

    .top_nav li a:hover {
        background: #e5bf17;
    }

    .top_nav li a {
        padding: 8px 10px;
        color: rgb(0, 0, 0);
        font-weight: bold;
        text-decoration: none;
    }

    input[type=text],
    input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        border: none;
        background: #D9D9D9;
    }

    .container {
        display: flex;
        width: 100%;
    }

    .container_R {
        width: 60%;
    }
    
    .container_L {
        width: 40%;
        right: 0;
        margin: 50px;
        padding: 20px;
        background-color: white;

    }

    .container_L input[type=submit] {
        display: flex;
        background-color: #81bd67;
        color: black;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.9;
        border-radius: 5px;
    }

    /*TITLE LOGIN12_40*/
    .title {
        width: 232px;
        color: white;
        top: 100px;
        left: 59px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 28px;
        opacity: 1;
        text-align: center;
    }

    /*userId8_4*/
    .Form {
        width: 10%;
        color: rgba(0, 0, 0, 1);
        background-color: rgba(217, 217, 217, 1);
        position: absolute;
        top: 222px;
        left: 13px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 48px;
        opacity: 1;
        text-align: left;
    }

    .name {
        color: #fff;
    }

    .picture {
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        padding: 10% 0;
        margin-bottom: 0;
    }

    footer {

        background: rgba(0, 173, 180, 1);
        color: black;
        opacity: 1;
        top: 957px;
        left: 0px;
        overflow: hidden;
        text-align: center;
    }

    .btn1 {
        margin-left: 50px
    }

    .btn2 {
        margin-left: 120px;
    }
</style>