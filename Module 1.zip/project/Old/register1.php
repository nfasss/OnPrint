<!DOCTYPE html>
<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Inter&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <div class="top_nav">
            <ul>
                <img src="ONPRINT LOGO.png" style="float:left;" alt="ONPRINT" width="40" height="40">
                <li style="float:left;"><a href="#explore">EXPLORE</a></li>
                <li style="float:right;"><a href="#home">Home</a></li>
                <li style="float:right;"><a href="#order">Order</a></li>
                <li style="float:right;"><a href="#profile">Our Profile</a></li>
                <li style="float:right;"><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </header>
    

    <div class="container">
        <div class="container_R">
            <span class="title">
                <h2>NEW LOGIN ACCOUNT</h2>
            </span>
        </div>
        <div class="container_L">
            <form class="myForm" action="login.php" method="post">
                <label for="name">First Name:</label>
                <input type="text" name="UserFirstName" placeholder="Enter First Name"><br>
                <label for="name">Last Name:</label>
                <input type="text" name="UserLastName" placeholder="Enter Last Name"><br>
                <label for="name">Email:</label>
                <input type="text" name="UserEmail" placeholder="Enter Email"><br>
                <label for="name">Phone Number:</label>
                <input type="text" name="UserPhoneNum" placeholder="Enter Phone Number"><br>
                <label for="name">Address:</label>
                <input type="text" name="UserAddress" placeholder="Enter Address"><br>
                <label for="name">State:</label>
                <input type="text" name="UserState" placeholder="Enter State"><br>
                <label for="name">Poscode:</label>
                <input type="text" name="UserPoscode" placeholder="Enter Poscode"><br>

                <br>
                <input type="button" class="btn1" value="Clear" style="padding: 10px 50px;">
                <input type="submit" class="btn2" value="Submit" style="padding: 10px 50px;">
            </form>

        </div>
    </div>
    <footer>
        <h4>Unless explicitly stated otherwise, all material is copyright &copy; OnPrint 2022.</h4>
    </footer>
    <?php
    if (isset($_POST['submit'])) {
        include("database.php");

        // to create a query to be executed in sql
        if (
            empty($_POST['UserFirstName']) ||
            empty($_POST['UserLastName']) ||
            empty($_POST['UserEmail']) ||
            empty($_POST['UserPhoneNum']) ||
            empty($_POST['UserAddress']) ||
            empty($_POST['UserState']) ||
            empty($_POST['UserPoscode'])
        ) {
        }

        //value $var = $_POST['']
        $firstname = $_POST['UserFirstName'];
        $query = "INSERT INTO user(UserID, UserPassword, UserFirstName, UserLastName, UserEmail, UserPhoneNum, UserAddress, UserState, UserPoscode) VALUES ('" . $firstname . "','[value-2]','[value-3]','[value-4]','[value-5]','[value-6]','[value-7]','[value-8]','[value-9]')"
            or die(mysqli_connect_error());

        // to run sql query in database
        $result = mysqli_query($link, $query);

        if ($result) {
            //Check whether the insert was successful or not
    
            echo ("Data insert");

        } else {
            echo ("Fail");
            /* $sql = "INSERT INTO users(UserFirstName,UserLastName,UserEmail,UserPhoneNum,UserAddress,UserState,UserPoscode,) VALUES('".$_POST['UserFirstName']."','".$_POST['UserLastName']."','".$_POST['UserEmail']."','".$_POST['UserPhoneNum']."','".$_POST['UserAddress']."','".$_POST['UserState']."','".$_POST['UserPoscode']."')";
            mysqli_query($db, $sql);
            */
        }
    }
?>


    
</body>

</html>

<style>
    * {
        box-sizing: border-box;
    }

    .img {
        margin-top: 0px;
    }

    body {
        font-size: 14px;
        width: 100%;
        height: 827px;
        background: rgba(2, 53, 121, 1);
        opacity: 1;
        position: absolute;
        top: 0px;
        left: 0px;

    }

    /* Setting top_nav */
    header {
        background-color: #FFDE59;
        margin: 0;
        height: 50px;

    }

    .top_nav {
        left: 0px;
        top: 0px;
        margin: 0px;
        border: 0;
        padding-top: 10px;
        width: 100%;
        font-size: 20px;

    }

    .top_nav ul {
        /*    width: 100%; */
        display: inline;
        padding: 0 50px;
        color: black;
        text-align: center;
        /*    overflow: hidden; */
        Left: 0px;
        margin: 0px;

    }

    .top_nav li {
        margin-right: 0;
        text-transform: uppercase;
        letter-spacing: 0px;
        list-style-type: none;
    }

    .top_nav li a:hover {
        background: #e5bf17;
    }

    .top_nav li a {
        padding: 8px 10px;
        color: rgb(0, 0, 0);
        font-weight: bold;
        text-decoration: none;
    }

    input[type=text],
    input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        border: none;
        background: #D9D9D9;
    }

    .container {
        display: flex;
        width: 100%;
    }

    .container_R {
        width: 60%;
    }

    .container_L {
        width: 40%;
        right: 0;
        margin: 50px;
        padding: 20px;
        background-color: white;

    }

    .container_L input[type=submit] {
        display: flex;
        background-color: #81bd67;
        color: black;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.9;
        border-radius: 5px;
    }

    /*navbar_footer3_64*/
    footer {

        background: rgba(0, 173, 180, 1);
        color: black;
        opacity: 1;
        top: 957px;
        left: 0px;
        overflow: hidden;
        text-align: center;
    }

    /*TITLE LOGIN12_40*/
    .title {
        width: 232px;
        color: white;
        top: 100px;
        left: 59px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 28px;
        opacity: 1;
        text-align: center;
    }

    /*userId8_4*/
    .Form {
        width: 10%;
        color: rgba(0, 0, 0, 1);
        background-color: rgba(217, 217, 217, 1);
        position: absolute;
        top: 222px;
        left: 13px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 48px;
        opacity: 1;
        text-align: left;
    }

    .name {
        color: #fff;
    }

    .picture {
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        padding: 10% 0;
        margin-bottom: 0;
    }

    .btn1 {
        margin-left: 10px
    }

    .btn2 {
        margin-left: 50px;
        
    }
</style>