<?php
function showUserList()
{

    include("database.php");
    echo "<table>";
    //  echo "<tr>" . "<th>No.</th>" . "<th>User ID</th>" . "<th>User First Name</th>" . "<th>User Last Name</th>" . "<th>User Type</th>" . "<th>Email</th>" . "<th>Address</th>" . "<th>Phone No</th>";

    //customer 
    //SELCT * FROM user WHERE UserID LIKE '". $_SESSION["UserID"]."';";

    //admin
    //$query="SELECT * FROM user WHERE UserType LIKE '%STU%' OR '%STA$";";

    $link = mysqli_connect("localhost", "root", "", "group2");
    $query = "SELECT * FROM user";
    $result = mysqli_query($link, $query);
    $couter = 1;
    if (mysqli_num_rows($result) > 0) {
        while ($UserData = mysqli_fetch_assoc($result)) {

            $UserID = $UserData["UserID"];
            $UserFirstName = $UserData["UserFirstName"];
            $UserLastName = $UserData["UserLastName"];
            $UserEmail = $UserData["UserEmail"];
            $UserPhoneNum = $UserData["UserPhoneNum"];
            $UserAddress = $UserData["UserAddress"];
            $UserState = $UserData["UserState"];
            $UserPoscode = $UserData["UserPoscode"];
            $UserType = $UserData["UserType"];

?>
            <table>
                <tr>
                    <th>No</th>
                    <th>User ID</th>
                    <th>UserFirstName</th>
                    <th>UserLastName</th>
                    <th>UserEmail</th>
                    <th>UserPhoneNum</th>
                    <th>UserAddress
                    <th>UserState</th>
                    <th>UserPoscode</th>
                    <th>UserType</th>
                </tr>
                <tr>
                    <td><?php echo $couter; ?></td>
                    <td><?php echo $UserID ; ?></td>
                    <td><?php echo $UserFirstName ?></td>
                    <td><?php echo $UserLastName ?></td>
                    <td><?php echo $UserEmail ?></td>
                    <td><?php echo $UserPhoneNum ?></td>
                    <td><?php echo $UserAddress ?></td>
                    <td><?php echo $UserState ?></td>
                    <td><?php echo $UserPoscode ?></td>
                    <td><?php echo $UserType ?></td>
                    <td> <a href="delete_mysql.php?id=<?php echo $UserID; ?>">Delete</a>
                    <td>
                </tr>
            </table>

<?php
        }
    } else {
        echo "0 result";
    }
}


?>