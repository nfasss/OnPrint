<!DOCTYPE html>
<html>

<head>
    <link href="https://fonts.googleapis.com/css?family=Inter&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <header>
        <div class="top_nav">
            <ul>
                <img src="ONPRINT LOGO.png" style="float:left;" alt="ONPRINT" width="40" height="40">
                <li style="float:left;"><a href="#explore">EXPLORE</a></li>
                <li style="float:right;"><a href="#home">Home</a></li>
                <li style="float:right;"><a href="#order">Order</a></li>
                <li style="float:right;"><a href="#profile">Our Profile</a></li>
                <li style="float:right;"><a href="#contact">Contact</a></li>
            </ul>
        </div>
    </header>
    <div class="title">
        <h2>User Profile</h2>
    </div>
    <div class="container_L">
        <div id="userProfile">
            <form action="#" method="post">

                <table id="myTable">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>User ID</th>
                            <th>UserFirstName</th>
                            <th>UserLastName</th>
                            <th>User Email</th>
                            <th>UserAddress</th>
                            <th>UserPhoneNum</th>
                        </tr>
                        
                        <tr>
                        
                        </tr>
                    </thead>
                   
                </table>

                <br>
                <input type="button" class="btn1" value="Delete" style="padding: 10px 50px;" onclick=" location.href='delete_mysql.php'">
                <input type="button" class="btn2" value="Edit" style="padding: 10px 50px;" onclick=" location.href='update_mysql.php'">

                <br> <br>
                <input type="button" class="btn1" value="Add User" style="padding: 10px 50px;" onclick=" location.href='register.php'">
                <input type="button" class="btn2" value="Save" style="padding: 10px 50px;" 
            </form>
        </div>
    </div>
    <footer>
        <h4>Unless explicitly stated otherwise, all material is copyright &copy; OnPrint 2022.</h4>
    </footer>
    <?php
    if (isset($_POST['save'])) {
        include 'database.php';
        $selected = $_POST['selected'];
        $sql = "SELECT * FROM user WHERE user.UserType='$selected'";
        $result = mysqli_query($conn, $sql);

        if ($selected == "") {
            echo "<h4>Please select a UserTyoe.</h4>";
        } else {
            echo "<h4>Selected : " . $selected . "</h4>";
            echo "<table>";
            echo "<tr>" . "<th>UserFirstName</th>" .  "<th>UserLastName</th>" . "<th>UserEmail</th>" . "<th>UserAddress</th>" . "<th>UserPhoneNum</th>" . "</tr>";
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $UserID = $row["UserID"];
                    $UserFirstName = $row["UserFirstName"];
                    $UserLastName = $row["UserLastName"];
                    $UserEmail = $row["UserEmail"];
                    $UserAddress = $row["UserAddress"];
                    $UserPhoneNum = $row["UserPhoneNum"];

                    echo "<tr><td>" .
                        "$UserID" . "</td><td>" .
                        "$UserFirstName" . "</td><td>" .
                        "$UserLastName" . "</td><td>" .
                        "$UserEmail" . "</td><td>" .
                        "$UserAddress" . "</td><td>" .
                        "$UserPhoneNum" . "</td><td>" .
                        "<a href='update_msql.php?id=$id'>Edit</a> &nbsp <a href='delete_mysql.php?id=$id'>Delete</a>" . "</td></tr>";
                }
            } else {
                echo "No result found.";
            }
            echo "</table>";
            mysqli_close($conn);
        }
    }
    ?>
</body>

</html>
<style>
    * {
        box-sizing: border-box;
    }

    .img {
        margin-top: 0px;
    }

    body {
        font-size: 14px;
        width: 100%;
        height: 827px;
        background: rgba(2, 53, 121, 1);
        opacity: 1;
        position: absolute;
        top: 0px;
        left: 0px;

    }

    /* Setting top_nav */
    header {
        background-color: #FFDE59;
        margin: 0;
        height: 50px;

    }

    .top_nav {
        left: 0px;
        top: 0px;
        margin: 0px;
        border: 0;
        padding-top: 10px;
        width: 100%;
        font-size: 20px;

    }

    .top_nav ul {
        /*    width: 100%; */
        display: inline;
        padding: 0 50px;
        color: black;
        text-align: center;
        /*    overflow: hidden; */
        Left: 0px;
        margin: 0px;

    }

    .top_nav li {
        margin-right: 0;
        text-transform: uppercase;
        letter-spacing: 0px;
        list-style-type: none;
    }

    .top_nav li a:hover {
        background: #e5bf17;
    }

    .top_nav li a {
        padding: 8px 10px;
        color: rgb(0, 0, 0);
        font-weight: bold;
        text-decoration: none;
    }

    input[type=text],
    input[type=password] {
        width: 100%;
        padding: 15px;
        margin: 5px 0 22px 0;
        border: none;
        background: #D9D9D9;
    }

    .container {
        display: flex;
        width: 100%;
    }

    .container_R {
        width: 60%;
    }

    .container_L {
        width: 40%;
        right: 0;
        margin: 50px;
        padding: 20px;
        background-color: white;

    }

    .container_L input[type=submit] {
        display: flex;
        background-color: #81bd67;
        color: black;
        padding: 16px 20px;
        border: none;
        cursor: pointer;
        width: 100%;
        opacity: 0.9;
        border-radius: 5px;
    }

    footer {
        width: 100%;
        background: rgba(0, 173, 180, 1);
        color: black;
        left: 0px;
        bottom: 0;
        text-align: center;
        margin: auto;
        position: fixed;
        padding: 30px 0px 30px 0px;
    }

    .title {
        width: 232px;
        color: white;
        top: 100px;
        left: 59px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 28px;
        opacity: 1;
        text-align: center;
    }

    /*userId8_4*/
    .Form {
        width: 10%;
        color: rgba(0, 0, 0, 1);
        background-color: rgba(217, 217, 217, 1);
        position: absolute;
        top: 222px;
        left: 13px;
        font-family: Inter;
        font-weight: Regular;
        font-size: 48px;
        opacity: 1;
        text-align: left;
    }

    .name {
        color: #fff;
    }

    .picture {
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        padding: 10% 0;
        margin-bottom: 0;
    }

    .btn1 {
        margin-left: 10px
    }

    .btn2 {
        margin-left: 50px;

    }
    .table,thead,tr,th{
        border: 1px solid black;
        line-height: 32px;
        vertical-align: top;
        border-bottom: 1px solid #e7e7e7;
    }
</style>